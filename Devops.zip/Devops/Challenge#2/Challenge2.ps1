$url=http://169.254.169.254/latest/meta-data/                                     #Passing the Meta-Data URL
$base=Invoke-RestMethod -uri $url                                                 #To retrieve MetaData and store in a variable
$mac=''

foreach ($value in $base)                                                         #Checking each MetaData value
 {
  $executeUrl = $url+$value
  $exePath = ''
  	if($value.Contains('/') -eq 0)                                                #Fetching Meta Data Value for top level 
	{
		$metaData = Invoke-RestMethod -uri $executeUrl 
        showInfo($value, $metaData)                                               # Function to display output ( Index,Meta Data )
		if($value -eq "mac") { $mac = $metaData }                               
	}
	else                                                                          #Going Down Level
	{
    
		$hasChildData = Invoke-RestMethod -uri $executeUrl
		switch($value)                                                            #Switch case for special cases
		   {
		    {"public-keys/" -or "placement/" -or "metrics/"}
              {
				$replaceData = $hasChildData                                 
				$exePath = $url+$value+$replaceData
				showInfo(($value+$replaceData),(Invoke-RestMethod -uri $exePath))
              }            
			"network/" 
              {
				$networkPath = "network/interfaces/macs/" + (ToLower($mac)) + "/"
				$networkInfo = "device-number", "local-hostname", "local-ipv4s", "mac", "owner-id", "public-hostname", "security-groups", "security-groups-ids", "subnet-id", "subnet-ipv4-cidr-block", "vpc-id", "vpc-ipv4-cidr-block"

				foreach($networkVal in $networkInfo)
				{
					$networkData = $networkPath+$networkVal
					showInfo($networkData,(Invoke-RestMethod -uri "$url+$networkData"))
				}
              }  
			default
			  {
                $childNode = Invoke-RestMethod -uri $hasChildData
				foreach($child in $childNode)
				{
				   $exeUrl = $url+$value+$child
				   showInfo(($value+$child),(Invoke-RestMethod -uri($exeUrl)))
				}
              }  
		}
	}
 }   
 function showInfo($meta, $value)                                                      #To display Output
 {
     Write-Output $meta":"$value | ConvertTo-Json                                      #To Output in JSON
 }   