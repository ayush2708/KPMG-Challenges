# Terraform and AWS

A template and configuration that reuses modules from the terraform registry to
create a three tier VPC and deploy a sample app to it, where:

The public presentation tier is an nginx host which can serve static content
that passes API requests through to the private application tier.

The private application tier hosts an application that persists data
in the DB tier.

The db tier hosts an RDS PostgreSQL instance.

# Usage

Take a copy of terraform.tfvars.template and substitute required values.

Apply as per normal, i.e. `terraform apply -var-file=terraform.tfvars`

Note : Both the presentation and application tier needs to setup with custom app environment data and configuration needs to be done to run it with ELB.